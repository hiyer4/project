import java.util.NoSuchElementException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

// --== CS400 File Header Information ==--
// Name: Colin Green
// Email: cjgreen3@wisc.edu
// Team: BF
// TA: Brianna Cockrhan
// Lecturer: Gary Dahl
// Notes to Grader: <optional extra notes>
/**
 * This class creates a Hashtable with a keyvalue and movie object.
 * 
 * @author Colin Green
 *
 * @param <String>
 * @param <Movie>
 */
public class MovieHashMap<String, Movie> implements MapADT<String, Movie> {
  // Fields for the HashTableMap class
  private int capacity;
  private int size;
  private LinkedList<HTObject> hashArr[];

  class HTObject {
    private String key;
    private Movie value;

    /**
     * This is the contructor of the HTObject
     * 
     * @param key
     * @param value
     */
    public HTObject(String key, Movie value) {
      this.key = key;
      this.value = value;
    }

    /**
     * This is the getter method for the key
     * 
     * @return this.key
     */
    public String getKey() {
      return this.key;
    }

    /**
     * This is the getter method for the value
     * 
     * @return this.value
     */
    public Movie getValue() {
      return this.value;
    }

    /**
     * This is the setter method for the key
     * 
     * @param key
     */
    public void setKey(String key) {
      this.key = key;
    }


  }

  /**
   * Contructor for the HashTableMap
   * 
   * @param capacity
   */
  public MovieHashMap(int capacity) {
    this.capacity = capacity;
    hashArr = new LinkedList[capacity];


  }

  /**
   * Default contructor for the HashTableMap the default capacity is 10
   */
  public MovieHashMap() {
    this.capacity = 10;
    hashArr = new LinkedList[capacity];


  }

  /**
   * Hashes the key by using the modulus operator.
   * 
   * @param key
   * @return hashVal
   */
  public int hash(String key) {
    int hashVal = Math.abs((key.hashCode() % this.capacity));
    return hashVal;
  }

  /**
   * This method puts a HTObject into the hashtable. The HTObject must have a key and value. The
   * specifications for the hash table are to make sure the load factor (size/capacity) is less than
   * your equal to 80%. If it's not than call the expand method which doubles the capacity and
   * copies. If there is a duplicate key then return false. When a HTObject is being added, create a
   * linkedlist and add the HTObject. If different keys hash to the same value add the new instance
   * of HTObject to the linkedlist of the same hashVal.
   * 
   * @param title
   * @param value
   * @return true or false based on if a HTObject was added
   */
  @Override
  public boolean put(String title, Movie value) {

    // hash key
    int hashVal = hash(title);
    // check if the array needs to expanded
    double sizeDouble = size;
    double capacityDouble = capacity;
    double loadFactor = sizeDouble / capacityDouble;

    // double loadFactor = (double) size / (double )capacity;
    if (loadFactor >= 0.8) {
      expand();
    }

    // check for duplicates
    if (containsKey(title)) {
      return false;
    }


    // no value found, create linked list with
    if (hashArr[hashVal] == null) {
      // CHECK IF NULL OR EMPTY LIST
      LinkedList<HTObject> list = new LinkedList<HTObject>();
      HTObject inst = new HTObject(title, value);
      list.add(inst);
      hashArr[hashVal] = list;
      size++;
      // re check the load factor
      loadFactor = (double) size / (double) capacity;
      if (loadFactor >= 0.8) {
        expand();
      }
      return true;
    }
    // chain onto the list with diff value
    if (hashArr[hashVal] instanceof LinkedList && hashArr[hashVal].size() > 0) {

      HTObject inst = new HTObject(title, value);
      hashArr[hashVal].add(inst);
      size++;
      // re check the load factor
      loadFactor = (double) size / (double) capacity;
      if (loadFactor >= 0.8) {
        expand();
      }
      return true;
    }



    return false;
  }

  /**
   * This method doubles capacity and re hashes.
   * 
   * @return true or false if the capacity and elements were copied to new hashArr
   */
  public boolean expand() {
   // LinkedList<HTObject> 
    LinkedList<HTObject> tmp[] = new LinkedList[capacity * 2];
    this.capacity = 2 * capacity;


    // iterate through the array and linked list
    for (int i = 0; i < capacity/2; i++) {
      if (hashArr[i] != null) {
        LinkedList<HTObject> chain = (LinkedList<HTObject>) hashArr[i];
       tmp[i] = chain; 

      }
    }
    hashArr = tmp;
    return true;

  }

  /**
   * This method passes a key and returns the value/ movie object that exists at that key
   * 
   * @param key
   * @throws NoSuchElementException
   * @return Movie/value that is at that key
   */
  @Override
  public Movie get(String key) throws NoSuchElementException {
    // hash
    int hashVal = hash(key);

    LinkedList<HTObject> chain = (LinkedList<HTObject>) hashArr[hashVal];
    if (chain == null) {
      throw new NoSuchElementException();

    }
    for (HTObject curr : chain) {
      if (curr.getKey().equals(key)) {
        return curr.getValue();
      }
    }

    throw new NoSuchElementException();
  }

  /**
   * Returns the size of hashArr
   * 
   * @return size
   */
  @Override
  public int size() {
    return this.size;
  }

  /**
   * returns the capacity
   * 
   * @return capacity
   */
  public int capacity() {
    return this.capacity;
  }

  /**
   * This method checks the hashtable and returns if a boolean.
   * 
   * @return true or false if the hashTable at key contains key
   */
  @Override
  public boolean containsKey(String title) {

    for (int i = 0; i < capacity; i++) {
      if (hashArr[i] != null) {
        LinkedList<HTObject> chain = (LinkedList<HTObject>) hashArr[i];
        for (HTObject curr : chain) {
          if (curr.getKey().equals(title)) {
            return true;
          }
        }
      }

    }
    return false;
  }

  /**
   * This method returns the value of the specified key and removes it from the hash table array.
   * 
   * @param key
   * @return movie
   */
  @Override
  public Movie remove(String key) {

    for (int i = 0; i < capacity; i++) {
      if (hashArr[i] != null) {
        LinkedList<HTObject> chain = (LinkedList<HTObject>) hashArr[i];
        for (HTObject curr : chain) {
          if (curr.getKey().equals(key)) {

            Movie vT = curr.getValue();
            // curr.setValue(null);
            int hashVal = hash(key);

            hashArr[hashVal] = null;
            size--;
            return vT;
          }
        }
      }

    }

    return null;
  }

  /**
   * This method clears the hash table array and all the data within it.
   */
  @Override
  public void clear() {
    LinkedList<HTObject> tmp[] = new LinkedList[capacity];
    this.hashArr = tmp;
    this.size = 0;
    this.capacity = 10;

  }
  
  

  

}


